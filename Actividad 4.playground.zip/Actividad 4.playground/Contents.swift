import UIKit

var datos = [3,6,9,2,4,1]
// Numeros menor a 5
for num in datos{
    if(num < 5){
        print(num)
    }

}

// Funciones
func suma(x:Int, y:Int )-> Int{
    return x + y
}

func potencia(x:Int, y:Int )-> Decimal{
    return pow(Decimal(x), y)
}

// Enumeraciones
enum meses{
    case enero
    case febrero
    case marzo
    case abril
    case mayo
    case junio
    case julio
    case agosto
    case septiembre
    case octubre
    case noviembre
    case diciembre
}


var queMesEs:meses
queMesEs = .octubre

switch queMesEs{
case .enero:
    print("enero")
case .febrero:
    print("febrero")
case .marzo:
    print("marzo")
case .abril:
    print("abril")
case .mayo:
    print("mayo")
case .junio:
    print("junio")
case .julio:
    print("julio")
case .agosto:
    print("agosto")
case .septiembre:
    print("septiembre")
case .octubre:
    print("octubre")
case .noviembre:
    print("noviembre")
case .diciembre:
    print("diciembre")
    
}
